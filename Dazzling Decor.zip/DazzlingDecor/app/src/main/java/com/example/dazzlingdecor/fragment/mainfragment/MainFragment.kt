package com.example.dazzlingdecor.fragment.mainfragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.HORIZONTAL
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.dazzlingdecor.R
import com.example.dazzlingdecor.adapter.RecyclerViewCategoriesWallpaper
import com.example.dazzlingdecor.apihelper.ApiHelper
import com.example.dazzlingdecor.databinding.FragmentMainBinding
import com.example.dazzlingdecor.model.DataModel
import com.example.dazzlingdecor.model.PhotosModel
import com.example.dazzlingdecor.screens.MainActivity
import com.example.dazzlingdecor.screens.wallpapercategory.WallpaperCategoryActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


 class MainFragment : Fragment() {
lateinit var binding:FragmentMainBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding=FragmentMainBinding.inflate(inflater,container,false)
        val apiHelper= ApiHelper.create()
        apiHelper.getCuratedImages(80).enqueue(object : Callback<DataModel> {
            override fun onResponse(call: Call<DataModel>, response: Response<DataModel>) {
                binding.recViewCurated.layoutManager=
                    StaggeredGridLayoutManager(1, LinearLayoutManager.HORIZONTAL)
                binding.recViewCurated.adapter=
                    RecyclerViewCategoriesWallpaper(requireContext(),response.body()!!.photos)
            }
            override fun onFailure(call: Call<DataModel>, t: Throwable) {
                Log.d("failure",t.message.toString())
                t.printStackTrace()
            }

        })

        binding.btnSearchWallpaper.setOnClickListener{
            val searchValue=binding.edtSearchWallpaper.text.toString()
            if (searchValue!=""){
            startActivity(Intent(this.requireContext(),WallpaperCategoryActivity::class.java).putExtra("search",searchValue))
        }else{
                Toast.makeText(requireContext(), "Please Enter Name", Toast.LENGTH_SHORT).show()
            }
            }


        return binding.root
    }


}