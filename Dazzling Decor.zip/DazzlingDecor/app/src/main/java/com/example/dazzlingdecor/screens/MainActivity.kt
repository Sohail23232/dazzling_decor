package com.example.dazzlingdecor.screens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.dazzlingdecor.R
import com.example.dazzlingdecor.adapter.RecyclerViewCategoriesWallpaper
import com.example.dazzlingdecor.apihelper.ApiHelper
import com.example.dazzlingdecor.databinding.ActivityMainBinding
import com.example.dazzlingdecor.fragment.DownloadFragment
import com.example.dazzlingdecor.fragment.ProfileFragment
import com.example.dazzlingdecor.fragment.mainfragment.MainFragment
import com.example.dazzlingdecor.model.DataModel
import com.example.dazzlingdecor.model.PhotosModel
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.navigation.NavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var fm:FragmentManager
    val check=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        fm=supportFragmentManager


        binding.bottomNavBar.setOnItemSelectedListener(object :NavigationBarView.OnItemSelectedListener{
            override fun onNavigationItemSelected(item: MenuItem): Boolean {
                if (item.itemId==R.id.menu_dashboard){
              loadFrag(MainFragment())
                }
                else if (item.itemId==R.id.menu_download){
                    loadFrag(DownloadFragment())
                }
                else if (item.itemId==R.id.menu_profile){
                    loadFrag(ProfileFragment())
                }
                return true
            }

        })
        binding.bottomNavBar.selectedItemId=R.id.menu_dashboard

    }
    fun loadFrag(fragment: Fragment){
        val ft=fm.beginTransaction()
        if (check){
            ft.add(R.id.container,fragment)
        }
        else{
            ft.replace(R.id.container,fragment)
        }
        ft.commit()
    }

}