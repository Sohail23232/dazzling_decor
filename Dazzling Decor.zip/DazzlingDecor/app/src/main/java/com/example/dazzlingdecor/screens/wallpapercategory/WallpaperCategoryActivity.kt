package com.example.dazzlingdecor.screens.wallpapercategory

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.GridLayoutManager
import com.example.dazzlingdecor.adapter.RecyclerViewCategoriesWallpaper
import com.example.dazzlingdecor.apihelper.ApiHelper
import com.example.dazzlingdecor.databinding.ActivityWallpaperCategoryBinding
import com.example.dazzlingdecor.model.DataModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class WallpaperCategoryActivity : AppCompatActivity() {
    lateinit var binding:ActivityWallpaperCategoryBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityWallpaperCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
val searchValue=intent.getStringExtra("search")

   val apiHelper=ApiHelper.create()
        apiHelper.getSearchImages("$searchValue",80).enqueue(object :Callback<DataModel>{
            override fun onResponse(call: Call<DataModel>, response: Response<DataModel>) {
                val noOfWallpaper=response.body()!!.per_page.toString()
                binding.txtWallpaperCategory.text=searchValue
                binding.txtWallpaperCount.text= "$noOfWallpaper wallpaper available"
             binding.recViewPerCategories.layoutManager= GridLayoutManager(this@WallpaperCategoryActivity,2)
                binding.recViewPerCategories.adapter=RecyclerViewCategoriesWallpaper(this@WallpaperCategoryActivity,response.body()!!.photos)
            }
            override fun onFailure(call: Call<DataModel>, t: Throwable) {
               Log.d("failure",t.message.toString())
                t.printStackTrace()
            }
        })
    }
}